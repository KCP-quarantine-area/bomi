#include "audiofilter.hpp"

auto AudioFilter::reset() -> void
{

}

auto AudioFilter::delay() const -> double
{
    return 0;
}

auto AudioFilter::setScale(double /*scale*/) -> void
{

}
