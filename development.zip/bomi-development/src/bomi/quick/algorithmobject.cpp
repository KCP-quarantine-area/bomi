#include "algorithmobject.hpp"

AlgorithmObject::AlgorithmObject(QObject *parent)
    : QObject(parent)
{

}

AlgorithmObject::~AlgorithmObject()
{

}

