#include <zlib.h>
#include <QFileDialog>

namespace Global {


}
