#include "__ENUM_LOWERS.hpp"

const std::array<__ENUM_NAMEInfo::Item, __ENUM_COUNT> __ENUM_NAMEInfo::info{{
__ENUM_INFOS
}};
