#include "mrlstate_old.hpp"

//auto MrlStateV2::metaProperty(const char *property) const -> QMetaProperty
//{
//    auto mo = metaObject();
//    const int idx = mo->indexOfProperty(property);
//    if (idx < 0)
//        return QMetaProperty();
//    return mo->property(idx);
//}
